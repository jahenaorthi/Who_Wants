#imports
from tkinter import Tk, Label, Button, PhotoImage, Frame, Entry
import random
from bankofquestions import bankofquestions 
import pygame

root = Tk()
root.title("Who Wants to Be")
root.geometry("1000x600")

class WhoWantsToBe_:
  pygame.mixer.init()

  def __init__(self, master):

    #frame
    self.master = master
    master.title("Who Wants to Be A Millionaire?")
    master.geometry("1000x600")
    self.questions = bankofquestions.copy()
    random.shuffle(self.questions)

    #creating labels
    self.balancelabel = Label(master, text="")
    self.balancelabel.place_forget()
    self.questionlabel = Label(master, text="")
    self.questionlabel.place_forget()


    #variables
    self.maxq = 15
    self.qn = 0
    self.balance = 0
    self.reward = 0
    self.removeoption = 1

    #creating buttons
    self.ybutton = Button(master, text="Yes", command=self.GetQuestion,state="disabled" )
    self.ybutton.place_forget()
    self.nbutton = Button(master, text="No", command=self.no,state="disabled")
    self.nbutton.place_forget()

    self.begin = Button(master, text="Begin", command=self.GetQuestion)
    self.begin.pack()
    
    self.option1 = Button(master, text=f"", command=self.choice1)
    self.option1.place_forget()
    
    self.option2 = Button(master, text=f"", command=self.choice2)
    self.option2.place_forget()
    
    self.option3 = Button(master, text=f"", command=self.choice3)
    self.option3.place_forget()
    
    self.option4 = Button(master, text=f"", command=self.choice4)
    self.option4.place_forget()

    self.fflabel = Button(master, text="50/50",command=self.fiftyfifty)
    self.fflabel.place_forget()
    #self.calllabel = Button(master, text="Call a Friend", command=self.callfriend)
    #self.calllabel.place_forget()
    self.audiencelabel = Button(master, text="Ask an Audience")
    self.audiencelabel.place_forget()

  #def callingfriendaudio(self):
    #pygame.mixer.Sound({question["audio"]})
    
  #def callfriend(self):
    #self.fflabel.config(state="disabled")
    
  def fiftyfifty(self):
    self.fflabel.config(state="disabled")

    #variables
    correctans = self.question["answer"]
    choices = self.question["choices"]
    #list of options
    choiceslist = [0, 1, 2, 3]

    # Shuffle
    random.shuffle(choiceslist)

    #loop thruough randomly
    for x in choiceslist:
        if choices[x] != correctans and self.removeoption >= 0:
            if x == 0:
                self.option1.pack_forget()
                self.removeoption -= 1
            elif x == 1:
                self.option2.pack_forget()
                self.removeoption -= 1
            elif x == 2:
                self.option3.pack_forget()
                self.removeoption -= 1
            elif x == 3:
                self.option4.pack_forget()
                self.removeoption -= 1

  def no(self):
    self.questionlabel.config(text="Congratulations! You won $"+str(self.balance))
    self.questionlabel.pack()
    self.ybutton.pack_forget()
    self.nbutton.pack_forget()
    
    #getting question
  def GetQuestion(self):
    #self.calllabel.pack()
    self.audiencelabel.pack(side="bottom")
    self.fflabel.pack()
    self.begin.pack_forget()
    self.nbutton.pack_forget()
    self.nbutton.config(state="disabled")
    self.ybutton.pack_forget()
    self.ybutton.config(state="disabled")
    if self.maxq >= 0:
      #track of how many questions left
      self.maxq -= 1
      self.qn +=1
      # Money reward for each question
      self.rewards = [1000000,500000,250000,125000,64000,32000,16000,8000,4000,2000,500,400,300,200,100]
      
      #getting question
      self.question = self.questions.pop(0)
      
      #displaying question
      self.questionlabel.config(text=f"{self.qn}. {self.question['question']}")
      self.questionlabel.pack()
      self.balancelabel.config(text=f"Balance: ${self.balance}")
      self.balancelabel.pack()
      
      #displaying buttons
      self.option1.config(text=f"{self.question['choices'][0]}",state="normal")
      self.option1.pack()
      self.option2.config(text=f"{self.question['choices'][1]}",state="normal")
      self.option2.pack()
      self.option3.config(text=f"{self.question['choices'][2]}",state="normal")
      self.option3.pack()
      self.option4.config(text=f"{self.question['choices'][3]}",state="normal")
      self.option4.pack()
    else:
      self.questionlabel.config(text="GAME OVER! HAHA")
      
             
  def choice1(self):
    c1 = self.question["choices"][0]
    #if answer is right
    if c1 == self.question["answer"]:
      self.balance = self.rewards[self.maxq]
      self.balancelabel.config(text=f"Balance: ${self.balance}")
      if self.maxq >= 0:
        self.questionlabel.config(text="Correct! Would you like to continue?")
        self.ybutton.config(state="normal")
        self.nbutton.config(state="normal")
        self.ybutton.pack()
        self.nbutton.pack()
      elif self.maxq == 0:
        self.questionlabel.config(text="GAME OVER! YOU HAVE WON $1 000 000")


      #removing display of choice buttons
      self.option1.pack_forget()
      self.option2.pack_forget()
      self.option3.pack_forget()
      self.option4.pack_forget()
      
      
    elif c1 != self.question["answer"]:
      self.questionlabel.config(text="WOMP WOMP")
      self.option1.config(state="disabled")
      self.option2.config(state="disabled")
      self.option3.config(state="disabled")
      self.option4.config(state="disabled")
      
  def choice2(self):
    c2 = self.question["choices"][1]
    #if answer is right
    if c2 == self.question["answer"]:
      self.balance = self.rewards[self.maxq]
      self.balancelabel.config(text=f"Balance: ${self.balance}")
      if self.maxq >= 0:
        self.questionlabel.config(text="Correct! Would you like to continue?")
        self.ybutton.config(state="normal")
        self.nbutton.config(state="normal")
        self.ybutton.pack()
        self.nbutton.pack()
      elif self.maxq == 0:
        self.questionlabel.config(text="GAME OVER! YOU HAVE WON $1 000 000")
      
      self.option1.pack_forget()
      self.option2.pack_forget()
      self.option3.pack_forget()
      self.option4.pack_forget()
      
    elif c2 != self.question["answer"]:
      self.questionlabel.config(text="WOMP WOMP")
      self.option1.config(state="disabled")
      self.option2.config(state="disabled")
      self.option3.config(state="disabled")
      self.option4.config(state="disabled")

  def choice3(self):
    c3 = self.question["choices"][2]
    #if answer is right
    if c3 == self.question["answer"]:
      self.balance = self.rewards[self.maxq]
      self.balancelabel.config(text=f"Balance: ${self.balance}")
      if self.maxq >= 0:
        self.questionlabel.config(text="Correct! Would you like to continue?")
        self.ybutton.config(state="normal")
        self.nbutton.config(state="normal")
        self.ybutton.pack()
        self.nbutton.pack()
      elif self.maxq == 0:
        self.questionlabel.config(text="GAME OVER! YOU HAVE WON $1 000 000")
      
      self.option1.pack_forget()
      self.option2.pack_forget()
      self.option3.pack_forget()
      self.option4.pack_forget()
      
    elif c3 != self.question["answer"]:
      self.questionlabel.config(text="WOMP WOMP")
      self.option1.config(state="disabled")
      self.option2.config(state="disabled")
      self.option3.config(state="disabled")
      self.option4.config(state="disabled")

  def choice4(self):
    c4 = self.question["choices"][3]
    #if answer is right
    if c4 == self.question["answer"]:
      self.balance = self.rewards[self.maxq]
      self.balancelabel.config(text=f"Balance: ${self.balance}")
      if self.maxq > 0:
        self.questionlabel.config(text="Correct! Would you like to continue?")
        self.ybutton.config(state="normal")
        self.nbutton.config(state="normal")
        self.ybutton.pack()
        self.nbutton.pack()
      elif self.maxq == 0:
        self.questionlabel.config(text="GAME OVER! YOU HAVE WON $1 000 000")
        
      
      self.option1.pack_forget()
      self.option2.pack_forget()
      self.option3.pack_forget()
      self.option4.pack_forget()
      
    elif c4 != self.question["answer"]:
      self.questionlabel.config(text="WOMP WOMP")
      self.option1.config(state="disabled")
      self.option2.config(state="disabled")
      self.option3.config(state="disabled")
      self.option4.config(state="disabled")

root.geometry("1000x600")
my_gui = WhoWantsToBe_(root)
root.mainloop()